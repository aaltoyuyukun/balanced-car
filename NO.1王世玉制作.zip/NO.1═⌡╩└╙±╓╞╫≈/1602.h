/*-----------------------------------------------
  ���ƣ�LCD1602.h
  ��д��wangshiyu
  ���ڣ�2013.11.25
  �޸ģ���ֲ
  ���ݣ�
  ���Ŷ������£�1-VSS 2-VDD 3-V0 4-RS 5-R/W 6-E 7-14 DB0-DB7 15-BLA 16-BLK
------------------------------------------------*/
#include<reg52.h> //����ͷ�ļ�


#ifndef __1602_H__
#define __1602_H__

#define CHECK_BUSY

sbit RS = P2^4;   //����˿� 
sbit RW = P2^5;
sbit EN = P2^6;

#define RS_CLR RS=0 
#define RS_SET RS=1

#define RW_CLR RW=0 
#define RW_SET RW=1 

#define EN_CLR EN=0
#define EN_SET EN=1

#define DataPort P0

/////////////////////////////��������///////////

 bit LCD_Check_Busy(void) ;

 void LCD_Write_Com(unsigned char com) ;

 void LCD_Write_Data(unsigned char Data) ;

 void LCD_Clear(void) ;

 void LCD_Write_String(unsigned char x,unsigned char y,unsigned char *s) ;

 void LCD_Write_Char(unsigned char x,unsigned char y,unsigned char Data) ;

 void LCD_Init(void) ;

 void DelayMs(unsigned char i);
 
 void Show(unsigned char k,unsigned char a,unsigned char dat);
   
#endif
