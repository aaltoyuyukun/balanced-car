#include <reg52.h>
#include"laba.h"


